#include "simd.h"
#include <memory>
#include <type_traits>
#include <cstring>
#include <sys/time.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <thread>
#include "/home/cc/gem5-avx/include/gem5/m5ops.h"

__attribute__((aligned(32))) float _alpha = 1e-3;
__attribute__((aligned(32))) float _betta1 = 0.9;
__attribute__((aligned(32)))float _betta2 = 0.999;
__attribute__((aligned(32))) float _eps = 1e-8;
__attribute__((aligned(32))) float _weight_decay = 0;
__attribute__((aligned(32))) bool _adamw_mode = true;
__attribute__((aligned(32))) bool _should_log = false;
__attribute__((aligned(32))) float _bias_correction=1;

__attribute__((aligned(32))) float _bias_correction1=0.1;
__attribute__((aligned(32))) float _bias_correction2=2;

// // float p[4000000];
//  float _alpha = 1e-3;
//  float _betta1 = 0.9;
// float _betta2 = 0.999;
//  float _eps = 1e-8;
//  float _weight_decay = 0;
//  bool _adamw_mode = true;
//  bool _should_log = false;
//  float _bias_correction=1;

//  float _bias_correction1=0.1;
//  float _bias_correction2=2;

void 
Step_AVX(size_t rounded_size,
                              float* _params,
                              float* grads,
                              float* _exp_avg,
                              float* _exp_avg_sq,
                              size_t _param_size,
                            //   __half* dev_params,
                              bool half_precision,
                              int tid,
                              int threads)

{
    // printf("start avx %d\n", tid);
    size_t new_rounded_size = 0;

    AVX_Data betta1_4;
    betta1_4 = SIMD_SET(_betta1);
    AVX_Data betta2_4;
    betta2_4 = SIMD_SET(_betta2);

    float betta1_minus1 = 1 - _betta1;
    float betta2_minus1 = 1 - _betta2;
    AVX_Data betta1_minus1_4;
    betta1_minus1_4  = SIMD_SET(betta1_minus1);
    AVX_Data betta2_minus1_4;
    betta2_minus1_4  = SIMD_SET(betta2_minus1);

    AVX_Data bias2_sqrt;
    bias2_sqrt  = SIMD_SET(_bias_correction2);

    AVX_Data eps_4;
    eps_4  = SIMD_SET(_eps);

    float step_size = -1 * _alpha / _bias_correction1;
    AVX_Data step_size_4;
    step_size_4  = SIMD_SET(step_size);

    float w_decay = -1 * _alpha * _weight_decay;
    AVX_Data weight_decay4;
    if (_weight_decay > 0)
        weight_decay4  = (_adamw_mode ? SIMD_SET(w_decay) : SIMD_SET(_weight_decay));

    // parameters partition
    float* local_params = _params + tid * _param_size;
    float* local_grads = grads + tid * _param_size ;
    float* local_exp_avg = _exp_avg + tid * _param_size;
    float* local_exp_avg_sq = _exp_avg_sq + tid * _param_size;


    // new_rounded_size = ROUND_DOWN(_param_size, SIMD_WIDTH * span);

    for (size_t  i= 0; i < _param_size; i += SIMD_WIDTH*span) {
       
        // 
//         size_t copy_size = TILE;
//         if ((t + TILE) > new_rounded_size) copy_size = new_rounded_size - t;
//         size_t offset = copy_size + t;
//         // if ((t / TILE) >= 2) { cudaStreamSynchronize(_streams[_buf_index]); }
//         // printf("start loop \n");
// // #pragma omp parallel for num_threads(10)
//         // printf("start runing");

//         for (size_t i = t; i < offset; i += SIMD_WIDTH * span) {
//             if (i + SIMD_WIDTH * span >= _param_size ){
//                 printf("overflow\n");
//                 continue;
//             }
//             printf("loop");
            __attribute__((aligned(64))) __m512 grad_4[span];
            simd_load(grad_4, local_grads + i, half_precision);

            __attribute__((aligned(64))) __m512 momentum_4[span];
            simd_load(momentum_4, local_exp_avg + i, false);

            __attribute__((aligned(64))) __m512 variance_4[span];
            simd_load(variance_4, local_exp_avg_sq + i, false);

            __attribute__((aligned(64))) __m512 param_4[span];
            simd_load(param_4, local_params + i, half_precision);

            if (_weight_decay > 0 && !_adamw_mode) {
                simd_fma(grad_4, param_4, weight_decay4, grad_4);
            }

            simd_mul(momentum_4, momentum_4, betta1_4);
            simd_fma(momentum_4, grad_4, betta1_minus1_4, momentum_4);
            simd_mul(variance_4, variance_4, betta2_4);
            simd_mul(grad_4, grad_4, grad_4);
            simd_fma(variance_4, grad_4, betta2_minus1_4, variance_4);
            simd_sqrt(grad_4, variance_4);
            simd_fma(grad_4, grad_4, bias2_sqrt, eps_4);
            simd_div(grad_4, momentum_4, grad_4);

            if (_weight_decay > 0 && _adamw_mode) {
                simd_fma(param_4, param_4, weight_decay4, param_4);
            }

            simd_fma(param_4, grad_4, step_size_4, param_4);
            // __attribute__((aligned(64))) __m512 a, b;
            // _mm512_store_ps(,a);
            // printf("finish computation");
            // float c[16];
            // for (int j=0; j<span;j++){
            //     _mm512_store_ps(c, a);
            // }

            // // simd_store(_params + i, param_4, false);
            // // _mm512_store_ps(_params+i, param_4[0].data);
            // // // gettimeofday(&t1 , NULL);
            // // // if (dev_params) {
            // // //     simd_store(_doubled_buffer[_buf_index] + (i - t), param_4, half_precision);
            // // // }
            // // for (int j=0; j<span;j++){
            //     _mm512_store_ps(_exp_avg+i, momentum_4[0]);
            // }
            float a[16];
            float b[16];
            float c[16];
            for(int j=0;j<span;j++){
                // printf("loop");
                memcpy(local_params+i+j*16, a, sizeof(float)*16);
                memcpy(local_exp_avg+i+j*16, b, sizeof(float)*16);
                memcpy(local_exp_avg_sq+i+j*16, c, sizeof(float)*16);
            }

            // // simd_store(_exp_avg + i, momentum_4, false);
            // for (int j=0; j<span;j++){
            //     _mm512_store_ps(_exp_avg_sq+i, variance_4[0]);
            // }
            // // simd_store(_exp_avg_sq + i, variance_4, false);
            // _mm512_store_ps(_exp_avg+i, momentum_4[0].data);
            // _mm512_store_ps(_exp_avg_sq+i, variance_4[0].data);

        // }

        // if (dev_params) {
        //     if (half_precision)
        //         launch_param_update_half(
        //             _doubled_buffer[_buf_index], dev_params + t, copy_size, _streams[_buf_index]);
        //     else
        //         launch_param_update(
        //             _doubled_buffer[_buf_index], dev_params + t, copy_size, _streams[_buf_index]);

        //     _buf_index = !_buf_index;
        // }
    }
    // printf("finished %d\n", tid);
    // *rounded_size = new_rounded_size;
}





int main(int argc, char* argv[]){

    // struct timeval t1, t2;
    // gettimeofday(&t1, NULL);
    // read data and allocate memory
    char* param_path = argv[1];
    char* grad_path  = argv[2];
    int threads = atoi(argv[3]);
    int total = atoi(argv[4]);

    // printf("asdfasd");
    // int threadnum = atoi(argv[3]);
    FILE* fp = fopen(param_path, "rb");
    FILE* fg = fopen(grad_path, "rb");
    if(fp == NULL || fg == NULL){
        printf("Can not open file\n");
    }
    
    // printf("Reading files\n");
    int size_p, size_g, len_g;
    fread(&size_p, 4, 1, fp);
    fread(&size_g, sizeof(int), 1, fg);
    // printf("%d %d\n", size_g, size_p);
    // printf("Allocate memory!");

    total = total/100;
    size_g=size_p = (total / threads);
    
    float* p = (float *) aligned_alloc(64,sizeof(float)*size_p);
    float* g = (float *) aligned_alloc(64,sizeof(float)*size_g);
    float* exp = (float *) aligned_alloc(64,sizeof(float)*size_p);
    float* exp_sg = (float *) aligned_alloc(64,sizeof(float)*size_g);
    
    fread(p, sizeof(int), size_p, fp);
    // printf("finish reading");

    fread(g, sizeof(int), size_g, fg);

    // printf("finish reading");
    memset(exp, 0, sizeof(float)*size_g);
    memset(exp_sg, 0, sizeof(float)*size_p);
    // // float* s = (float*)malloc(sizeof(int)*100000000);

    // // do the computation 
    // // create_adam_optimizer(0);

    // // // start compuation
    // struct timeval t1, t2;
    // // // // // // // for (int i=0;i<50;i++){
    // gettimeofday(&t1, NULL);
    // // for(int i=0; i < size_p; i++)
    //     // printf("length %d\n", len_p[i]);
    // // printf("osdi");
    // struct timeval t1, t2;
    // gettimeofday(&t1, NULL);
    // // Step_AVX<4>(0,p,g,exp,exp_sg,size_g,false);
    m5_reset_stats(0,0);
    // unsigned cpus = std::thread::hardware_concurrency();
    // thread **threads = new thread*[cpus];
    // printf("%d\n", cpus);
    // cpus = 48;
    // size_g /= cpus;
    // printf("%d\n", size_g);
    // // cpus = 1;
    // for (int i=0;i < cpus-1; i++){
    //     // printf("start thread\n");
    //     threads[i] = new thread(Step_AVX, 0, p, g, exp, exp_sg, size_g, false, i, cpus );
    // }

    // for (int i=0;i<cpus;i++){
    //     Step_AVX(0,p,g,exp,exp_sg,size_g,false, cpus-1, cpus);
    // }
    int cpus =48;
    Step_AVX(0,p,g,exp,exp_sg,size_p,false, 0, cpus);
    // Step_AVX<8>(0,p,g,exp,exp_sg,size_g,false, );

    // threads[0]->join();
    // threads[1]->join();
    // for (int i=0; i< cpus-1; i++){
    //     // printf("thread %d join\n", i);
    //     threads[i]->join();
    // }
    // m5_dump_stats(0,0);
    // ds_adam_step(0, 1, 0.01, 0.9,0.999, 1e-8, 0, false, p, g, exp, exp_sg, size_p);
    //     // printf("computation");
    // // // }
    // gettimeofday(&t2, NULL);
    // printf("update time: %lfms\n", (t2.tv_sec-t1.tv_sec) * 1000.0 + (t2.tv_usec -  t1.tv_usec) /1000.0 );
    // delete[] threads;

    // free(p);
    // free(g);
    // free(exp);
    // free(exp_sg);
    // free(len_p);


    return 0;
}


// int main(int argc, char* argv[]){

//     // read data and allocate memory
//     char* param_path = argv[1];
//     char* grad_path  = argv[2];
//     int threadnum = atoi(argv[3]);
//     FILE* fp = fopen(param_path, "rb");
//     FILE* fg = fopen(grad_path, "rb");
//     if(fp == NULL || fg == NULL){
//         printf("Can not open file\n");
//     }
    
//     // printf("Reading files\n");
//     int size_p, size_g, len_g;
//     fread(&size_p, 4, 1, fp);
//     fread(&size_g, sizeof(int), 1, fg);
//     printf("%d %d\n", size_g, size_p);
//     printf("Allocate memory!");
//     float** p = (float **) malloc(sizeof(float*)*size_p);
//     float** g = (float **) malloc(sizeof(float*)*size_g);
//     float** exp = (float **) malloc(sizeof(float*)*size_p);
//     float** exp_sg = (float **) malloc(sizeof(float*)*size_g);
//     // float* s = (float*)malloc(sizeof(int)*100000000);
//     int* len_p = (int*)malloc(sizeof(int) * size_p);
//     int total =0 ;
//     // this is to give the default value of len_
//     for(int i=0; i<size_p; i++){  
//         printf("read %d\n", i);
//         fread(&len_p[i], sizeof(int), 1, fp);
//         printf("%d ", len_p[i]);
//         fread(&len_g, sizeof(int), 1, fg);
//         //
//         total+=len_g;
//         p[i] = (float*)malloc(sizeof(float)*len_g);
//         g[i] = (float*)malloc(sizeof(float)*len_g);
//         // if (g[i]==nullptr) {printf("allocate rrror \n");}
//         exp[i] = (float*)malloc(sizeof(float)*len_g);
//         exp_sg[i] = (float*)malloc(sizeof(float)*len_g);
//         // if (len_g!=len_p[i]){
//         //     printf("error\n");    
//         // }
//         memset(exp[i], 0, sizeof(float)*len_g);
//         memset(exp_sg[i], 0, sizeof(float)*len_g);
//         fread(p[i], sizeof(float), len_p[i], fp);
//         fread(g[i], sizeof(float), len_g, fg);
//     }
//     fclose(fp);
//     fclose(fg);
//     total = total / threadnum;
//     float *work = (float*)malloc(sizeof(int)*total);
//     int i=0,index=0;
//     FILE* workload = fopen("/home/cc/avx_cpp_single_thread/para.bin", "wb");
//     FILE* workload1 = fopen("/home/cc/avx_cpp_single_thread/gradient.bin", "wb");
//     fwrite(&total, sizeof(int), 1, workload);
//     fwrite(&total, sizeof(int), 1, workload1);
//     while(true){
//         if (len_p[i]<total){
//             fwrite(p[i], sizeof(int), len_p[i], workload);
//             fwrite(g[i], sizeof(int), len_p[i], workload1);

//         }
//         else {
//             fwrite(p[i], sizeof(int), total, workload);
//             fwrite(g[i], sizeof(int), total, workload1);
//             break;
//         }
//         total -= len_p[i];
//         i++;

//     }
//     // printf("Finish all the reading\n");
//     // fclose(fp);
//     // fclose(fg);
//     fclose(workload);
//     fclose(workload1);
//     return 0;

//     // do the computation 
//     create_adam_optimizer(0);
    

//     // start compuation
//     struct timeval t1, t2;
//     gettimeofday(&t1, NULL);
//     for(int i=0; i < size_p; i++){
//         // printf("length %d\n", len_p[i]);
//         ds_adam_step(0, i, 0.01, 0.9,0.999, 1e-8, 0, false, p[i], g[i], exp[i], exp_sg[i], len_p[i]);
//         // printf("computation");
//     }
//     gettimeofday(&t2, NULL);
//     printf("update time: %lfms\n", (t2.tv_sec-t1.tv_sec) * 1000.0 + (t2.tv_usec -  t1.tv_usec) /1000.0 );

//     free(p);
//     free(g);
//     free(exp);
//     free(exp_sg);
//     free(len_p);
//     return 0;
// }


