
import torch 
import os
import io
import struct
import numpy as np
# load all the data

path_ws="../output1/"
grad=path_ws+"/gradients.bin"
param=path_ws+"/pytorch_model.bin"

for i in range(1,2):
    # path=path_ws + "./checkpoint-"+str(i)
    grad_path="./gradients.bin"
    param_path="./pytorch_model.bin"
    grad=torch.load(grad)
    param=torch.load(param)
    keys=grad.keys()
    # print(param.keys())
    f_param = open(param_path+"_c", "wb")
    f_grad  = open(grad_path+"_c", "wb")
    size_key = len(keys)
    # print(struct.pack(">i", 2233))
    # f_param.write( struct.pack("<i", 109483778))
    # f_grad.write( struct.pack("<i", 109483778))
    # f_param.write( struct.pack("<i", size_key))
    # f_grad.write( struct.pack("<i", size_key))
    # print(size_key)
    # print( (struct.pack(">i", size_key)))
    total =0
    for key in keys:
        total += len(torch.flatten(param[key]))
    f_param.write( struct.pack("<i", total))
    f_grad.write( struct.pack("<i", total))

    for key in keys:

        data_param = torch.flatten(param[key])
        data_grad = torch.flatten(grad[key])
        size_param = len(data_param)
        size_grad = len(data_grad)
        # total+=size_param

        print(size_param)
        print( struct.pack("<i", size_param))
        # f_param.write( struct.pack("<i", size_param))
        # f_grad.write( struct.pack("<i", size_param))

        for v in data_param.tolist(): 
            # print( (struct.pack("f", v)))
            # print(v)
            # break
            f_param.write( struct.pack("<f", v))

        for v in data_grad.data.tolist(): 
            # print(v)
            f_grad.write( struct.pack("<f", v))
        
        
        # break
    print(total)
    

    # for key in keys:
        # print(grad)
