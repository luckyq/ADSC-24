


bandwidth = 14.3*1024*1024*1024
cacheline = 64
link_latecy = 64.0 /bandwidth * 10**9

coh_latency = 2 * 1000

latency = link_latecy*1000 + coh_latency

filename = ['gpt2.txt', 'albert.txt', 'bert_large.txt','t5_large.txt']

final_time = [372255066, 708873590, 1058529758, 2285871680]

print(latency)
for i in range(4):
    file = filename[i]
    fp = open("/home/dongxu/gem5-avx/results/"+filename+"_timestamp", "r")

    lines = fp.readlines()
    start = int(lines[-1]-filename)
    length = len(lines)
    for index in range(0,length, 3):
        start = int(lines[index])
        if index+3 >= length :
            next = start + cycle
        else :
            next = int(lines[index+3])
        # print(start, cycle)
        if start + cycle + q_l< next:
            q_l = 0
        else:
            q_l = q_l - next + start + cycle
        # print(q_l)

    print(q_l)

    

